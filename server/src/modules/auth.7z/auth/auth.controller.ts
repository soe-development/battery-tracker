import { Controller, Get, HttpStatus, Post, Req, Res } from '@nestjs/common';
import { ActiveDirectoryService } from './active-directory.service';
import { AuthService } from './auth.service';
import { RoleService } from '../role/role.service';
import { UsersRolesService } from '../users-roles/users-roles.service';
import { JwtService } from '@nestjs/jwt';

@Controller('auth')
export class AuthController {
  constructor(
    private readonly authService: AuthService,
    private readonly adService: ActiveDirectoryService,
    private readonly roleService: RoleService,
    private readonly userRolesService: UsersRolesService,
    private readonly jwtService: JwtService,
  ) {}

  @Post('register')
  async register(@Req() request: any, @Res() response: any) {
    const { username, role } = request.body;

    const findUser = await this.authService.findOne({
      username: username.substring(0, username.indexOf('@')),
    });

    const findRole = await this.roleService.findOne({ name: role });

    if (findUser) {
      response.status(401).json({
        status: 401,
        message: 'This username already exists',
      });
    } else {
      const user = await this.authService.create({
        username: username.substring(0, username.indexOf('@')),
        email: username.substring(0, username.indexOf('@')) + '@soe.com.ua',
      });

      const usersRolesData = {
        user: user,
        role: findRole,
      };

      await this.userRolesService.create(usersRolesData);

      response.status(200).json({
        status: 200,
        message: 'Successful registration',
      });
    }
  }

  @Post('login')
  async login(@Req() request: any, @Res() response: any) {
    try {
      const { username, password } = request.body;

      const staticTestUsers = [
        {
          userId: 10,
          username: 'user_1',
          password: '1111',
          name: 'Переглядач загальної таблиці',
          role: {
            id: 10,
            name: 'commonTableViewer',
            permission: '2. View common table;',
          },
        },
        {
          userId: 11,
          username: 'user_2',
          password: '2222',
          name: 'Заповнювач довідників',
          role: {
            id: 11,
            name: 'fillerDirectories',
            permission: '3. Fill dirictories;',
          },
        },
        {
          userId: 12,
          username: 'user_3',
          password: '3333',
          name: 'Заповнювач Карти Обладнання',
          role: {
            id: 12,
            name: 'fillerEquipmentCard',
            permission: '4. Fill equipment card;',
          },
        },
        {
          userId: 13,
          username: 'user_4',
          password: '4444',
          name: 'Замінювач АКБ',
          role: {
            id: 13,
            name: 'replacementerOfBatteries',
            permission: '5. Replace battery;',
          },
        },
      ];

      let checker = 0;

      for (const element of staticTestUsers) {
        if (element.username === username && element.password === password) {
          const jwt = await this.jwtService.signAsync({
            userId: element.userId,
            name: element.name,
            username: element.username,
            role: element.role,
          });

          // response.cookie('jwt-btracker', jwt, {
          //   httpOnly: true,
          //   domain: process.env.SERVER_HOST, // заменить на другой домен
          //   secure: true,
          //   sameSite: 'lax',
          //   path: '/',
          // });

          checker = 1;

          response.status(200).json({
            status: 200,
            message: 'Authentication successful',
            jwtToken: jwt,
            user: {
              name: element.name,
              username: element.username,
              userId: element.userId,
            },
            route: 'cabinet',
          });
          break;
        }
      }

      if (checker === 0) {
        this.adService.setCredentials(username, password);
        const userInAD = await this.adService.getUser();

        if (!userInAD) {
          response
            .status(401)
            .json({ status: 401, message: 'Authentication failed' });
        } else {
          console.log(
            username.includes('@')
              ? username.substring(0, username.indexOf('@'))
              : username,
          );
          const userInLocalDB: any = await this.authService.findOne({
            username: username.includes('@')
              ? username.substring(0, username.indexOf('@'))
              : username,
          });

          if (userInLocalDB) {
            const jwt = await this.jwtService.signAsync({
              userId: userInLocalDB.id,
              name: userInAD[0].name,
              username: username.includes('@')
                ? username.substring(0, username.indexOf('@'))
                : username,
              role: userInLocalDB.userRoles[0].role,
            });

            // response.cookie('jwt-btracker', jwt, {
            //   httpOnly: true,
            //   domain: process.env.SERVER_HOST, // заменить на другой домен
            //   secure: true,
            //   sameSite: 'lax',
            //   path: '/',
            // });

            response.status(200).json({
              status: 200,
              message: 'Authentication successful',
              jwtToken: jwt,
              user: {
                name: userInAD[0].name,
                username: username.includes('@')
                  ? username.substring(0, username.indexOf('@'))
                  : username,
                userId: userInLocalDB.id,
              },
              route: 'cabinet',
            });
          } else {
            response
              .status(401)
              .json({ status: 401, message: 'Authentication failed' });
          }
        }
      }
    } catch (error) {
      console.log(error);
      response
        .status(500)
        .json({ status: 500, message: 'Internal server error' });
    }
  }

  @Post('user')
  async user(@Req() request: any, @Res() response: any) {
    try {
      const { token } = request.body;
      const dataToken = await this.jwtService.verifyAsync(token);

      if (!dataToken) {
        response.status(401).json({ status: 401, message: 'Not authorized' });
      } else {
        const { userId, name, username, role } = dataToken;
        response.status(200).json({
          status: 200,
          user: {
            userId: userId,
            name: name,
            username: username,
            role: role,
          },
        });
      }
    } catch (error) {
      response.status(401).json({ status: 401, message: 'Not authorized' });
    }
  }

  @Post('logout')
  async logout(@Res({ passthrough: true }) response: any) {
    response.cookie('jwt-btracker', '', {
      httpOnly: true,
      secure: true,
      domain: process.env.SERVER_HOST,
      path: '/',
      sameSite: 'lax',
      expires: new Date(0),
    });

    return {
      message: 'success',
    };
  }
}
